# Market, Users, Prototype

## Understand Your Market
*Provide links to the 3 websites you explored* 
https://www.airbnb.com/?tab_id=home_tab&refinement_paths%5B%5D=%2Fhomes&search_mode=flex_destinations_search&flexible_trip_lengths%5B%5D=one_week&location_search=MIN_MAP_BOUNDS&monthly_start_date=2023-12-01&monthly_length=3&price_filter_input_type=0&price_filter_num_nights=5&channel=EXPLORE&search_type=category_change&category_tag=Tag%3A8148

https://www.vrbo.com/?semcid=VRBO-US.B.GOOGLE.BT-c-EN.GT&semdtl=a118251470060.b1141973518615.g1kwd-13405466.e1c.m1CjwKCAiA9dGqBhAqEiwAmRpTC_ZVQoaOxYAafJ2Vqc5UKhC0phwGbtoFb-dwnwXvOxrFWFpopA3xYhoCKjoQAvD_BwE.r1499329b22b12540d5a8716f7ebc04d327bd8304dc546ac97134c31fc48e20280.c1O741gx-3gIsTI6MUvk7V2w.j19021712.k1.d1624922945643.h1e.i1.l1.n1.o1.p1.q1.s1.t1.x1.f1.u1.v1.w1&gad_source=1&gclid=CjwKCAiA9dGqBhAqEiwAmRpTC_ZVQoaOxYAafJ2Vqc5UKhC0phwGbtoFb-dwnwXvOxrFWFpopA3xYhoCKjoQAvD_BwE

https://www.bluepillow.com/

*Briefly explain why these websites are a relevant comparison* 
These websites are a relevant comparison because they have a lot of features that Marriot homes and villas will need to have. Also they are a vacation home rental site so they are compeitiors. 


*List at least 10 product features*
Users can search for specific features they are looking for in a vacation rental
Users can find very specific features that fit their needs (e.g. "ski in an out", "creative spaces", "earth homes" etc.)
Users can search for specific locations
Users can pick the amount of guests
Users can save the homes they love to narroe down their options
Users can find homes with free cancellation 
Users can search for pet friendly options 
Users can choose from hotel, condo, house, villa, etc.
Users can choose specific dates 
Users can search for specific regions (americas, europe, asia, africa, etc.)
Users can pick a price range
User can click on featured listings and it go to all the feature listings
... 


## Understand Your Users
*Write a short paragraph (50-100 words) describing the themes that emerged from the user research*

The user research suggests that the qualitative shows similar resutls to the quantitative in that both seem to not have a destination in mind when wanting to travel but know what kind of vacation they are looking for. 

The users pain points are they have an idea of what they want in a vacation but no way of narrowing down the "perfect" vacation for their needs. For example, they know they want a beach or they want somewhere different but don't know exactly where. They want it to be able to hold mulitple people and have fun activities to do nearby. When they try searching they don't know where to look because there is no way to narrow down possible homes that offer all the things they are looking for without a destination or a date. They also aren't familiar with the locations that are shown. They want more pop ups and expandable items. To find a destination they have to know a specific city in order to search for a "beach vacation".

I think that the users want to be able to narrow down what they want based off of features, locations, amenities, activities, rooms, price, etc. 


## Define and Prototype
*Paste a link to your prototype here* 
> **🗒️ NOTE:** Make sure you share your prototype file so that "anyone with the link" can view it. If we're unable to access your file, we'll be unable to give you credit. 
https://docs.google.com/presentation/d/1Vwsl_oAilS3GENhRIbREVnVF-nqIR2twkZBcbSvijaw/edit?usp=sharing 


*Don't forget to include a comment if you attempted any of the LevelUps, so that your grader knows to review your work and award the extra credit!* 

I tried to used higher fidelity for the prototype by including real images from the website and real maps.

I also included what I think could be improved/added to the website in order to make it more user friendly. 
...

